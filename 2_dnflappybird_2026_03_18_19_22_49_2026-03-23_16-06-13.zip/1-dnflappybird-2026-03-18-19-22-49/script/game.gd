extends Node2D

var scrollspeed: float = 3 
@onready var screenwidth:float = get_window().size.x
@onready var pipes = preload("res://tscn/pipes.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$bg1.position = Vector2(0,0)
	$bg2.position = Vector2(screenwidth, 0)  
	$Timer.start(2)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$bg1.position.x = $bg1.position.x - scrollspeed
	$bg2.position.x = $bg2.position.x - scrollspeed
	if $bg1.position.x <= -screenwidth:
		$bg1.position.x = screenwidth
	if $bg2.position.x <= -screenwidth:
		$bg2.position.x = screenwidth
#if pipe > -screenwidth
func create_pipes() -> void:
	var new_pipes = pipes.instantiate()
	add_child(new_pipes)
	new_pipes.position.x = screenwidth


func _on_timer_timeout() -> void:
	create_pipes()
	$Timer.start(2)

func _on_death() -> void:
	$bird.position.y = 0
	print("death")
