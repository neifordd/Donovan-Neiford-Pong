extends Area2D

var flap_power: float = 7.5
var grav: float = 25
var velocity: float = 0
var rotate: float = 5
signal death
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y += velocity
	velocity += grav * delta
	
	if Input.is_action_just_pressed("flap"):
		velocity = -flap_power
	else:
		velocity = velocity

	if velocity >= 0:
		rotation += deg_to_rad(rotate)
		$AnimatedSprite2D.play("idle")
	elif velocity < 0:
		rotation -= deg_to_rad(rotate)
		$AnimatedSprite2D.play("flap")
	else:
		return
	if position.y >= 800:
		position.y = 800
	rotation = clamp(rotation, deg_to_rad(-30), deg_to_rad(45))

func _on_area_entered(area: Area2D) -> void:
	if  area.name == "upperpipe":
		emit_signal("death")
		print("death")
	if  area.name == "lowerpipe":
		emit_signal("death")
		print("death")
